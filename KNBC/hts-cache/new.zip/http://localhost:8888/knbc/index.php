
<!DOCTYPE html>
<!--[if IE 7 ]>    <html prefix="og: http://ogp.me/ns#" lang="en-gb" class="isie ie7 oldie no-js"> <![endif]-->
<!--[if IE 8 ]>    <html prefix="og: http://ogp.me/ns#" lang="en-gb" class="isie ie8 oldie no-js"> <![endif]-->
<!--[if IE 9 ]>    <html prefix="og: http://ogp.me/ns#" lang="en-gb" class="isie ie9 no-js"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!-->
<html prefix="og: http://ogp.me/ns#" lang="en-gb" class="no-js">
<!--<![endif]-->
<!-- head -->
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<!-- this styles only adds some repairs on idevices  -->
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<base href="http://localhost:8888/knbc/index.php" />
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="generator" content="Joomla! - Open Source Content Management" />
	<title>Home</title>
	<link href="/knbc/index.php?format=feed&amp;type=rss" rel="alternate" type="application/rss+xml" title="RSS 2.0" />
	<link href="/knbc/index.php?format=feed&amp;type=atom" rel="alternate" type="application/atom+xml" title="Atom 1.0" />
	<link href="/knbc/templates/aaika/favicon.ico" rel="shortcut icon" type="image/vnd.microsoft.icon" />
	<link href="/knbc/plugins/system/jce/css/content.css?badb4208be409b1335b815dde676300e" rel="stylesheet" type="text/css" />
	<link href="http://localhost:8888/knbc/media/com_uniterevolution2/assets/rs-plugin/css/settings.css" rel="stylesheet" type="text/css" />
	<link href="http://localhost:8888/knbc/media/com_uniterevolution2/assets/rs-plugin/css/dynamic-captions.css" rel="stylesheet" type="text/css" />
	<link href="http://localhost:8888/knbc/media/com_uniterevolution2/assets/rs-plugin/css/static-captions.css" rel="stylesheet" type="text/css" />
	<link href="http://localhost:8888/knbc/modules/mod_icemegamenu/themes/clean/css/clean_icemegamenu.css" rel="stylesheet" type="text/css" />
	<link href="http://localhost:8888/knbc/modules/mod_icemegamenu/themes/clean/css/clean_icemegamenu-reponsive.css" rel="stylesheet" type="text/css" />
	<script src="/knbc/media/jui/js/jquery.min.js?6e3bf516a1e02f44002b59ad896f63d5" type="text/javascript"></script>
	<script src="/knbc/media/jui/js/jquery-noconflict.js?6e3bf516a1e02f44002b59ad896f63d5" type="text/javascript"></script>
	<script src="/knbc/media/jui/js/jquery-migrate.min.js?6e3bf516a1e02f44002b59ad896f63d5" type="text/javascript"></script>
	<script src="/knbc/media/k2/assets/js/k2.frontend.js?v=2.10.3&b=20200429&sitepath=/knbc/" type="text/javascript"></script>
	<script type="text/javascript">
jQuery(window).on('load',  function() {
				
			});function do_nothing() { return; }
	</script>

<!-- css -->
<!-- Google fonts - witch you want to use - (rest you can just remove) -->
<link href='http://fonts.googleapis.com/css?family=Open+Sans:300,300italic,400,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Raleway:400,100,200,300,500,600,700,800,900' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Dancing+Script:400,700' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Josefin+Sans:400,100,100italic,300,300italic,400italic,600,600italic,700,700italic' rel='stylesheet' type='text/css'>

<!--[if lt IE 9]>
		<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->

<!-- ######### CSS STYLES ######### -->

<link rel="stylesheet" href="/knbc/templates/aaika/css/reset.css" type="text/css" />
<link rel="stylesheet" href="/knbc/templates/aaika/css/style.css" type="text/css" />

<!-- font awesome icons -->
<link rel="stylesheet" href="/knbc/templates/aaika/css/font-awesome/css/font-awesome.min.css">

<!-- simple line icons -->
<link rel="stylesheet" type="text/css" href="/knbc/templates/aaika/css/simpleline-icons/simple-line-icons.css" media="screen" />

<!-- animations -->
<link href="/knbc/templates/aaika/js/animations/css/animations.min.css" rel="stylesheet" type="text/css" media="all" />

<!-- responsive devices styles -->
<link rel="stylesheet" media="screen" href="/knbc/templates/aaika/css/responsive-leyouts.css" type="text/css" />

<!-- shortcodes -->
<link rel="stylesheet" media="screen" href="/knbc/templates/aaika/css/shortcodes.css" type="text/css" />

<!-- slide panel -->
<link rel="stylesheet" type="text/css" href="/knbc/templates/aaika/js/slidepanel/slidepanel.css">

<!-- accordion -->
<link rel="stylesheet" type="text/css" href="/knbc/templates/aaika/js/accordion/style.css" />

<!-- progressbar -->
<link rel="stylesheet" href="/knbc/templates/aaika/js/progressbar/ui.progress-bar.css">

<!-- MasterSlider -->
<link rel="stylesheet" href="/knbc/templates/aaika/js/masterslider/style/masterslider.css" />
<link rel="stylesheet" href="/knbc/templates/aaika/js/masterslider/skins/default/style.css" />
<link href='/knbc/templates/aaika/js/masterslider/ms-lightbox.css' rel='stylesheet' type='text/css'>
<link href="/knbc/templates/aaika/js/masterslider/prettyPhoto.css"  rel='stylesheet' type='text/css'/>

<!-- icon hover -->
<link rel="stylesheet" href="/knbc/templates/aaika/js/iconhoverefs/component.css" />

<!-- basic slider -->
<link rel="stylesheet" href="/knbc/templates/aaika/js/basicslider/bacslider.css" />

<!-- cubeportfolio -->
<link rel="stylesheet" type="text/css" href="/knbc/templates/aaika/js/cubeportfolio/cubeportfolio.min.css">

<!-- flexslider -->
<link rel="stylesheet" href="/knbc/templates/aaika/js/flexslider/flexslider.css" type="text/css" media="screen" />
<link rel="stylesheet" type="text/css" href="/knbc/templates/aaika/js/flexslider/skin.css" />

<!-- tabs -->
<link rel="stylesheet" type="text/css" href="/knbc/templates/aaika/js/tabs/assets/css/responsive-tabs.css">
<link rel="stylesheet" type="text/css" href="/knbc/templates/aaika/js/tabs/assets/css/responsive-tabs2.css">
<link rel="stylesheet" type="text/css" href="/knbc/templates/aaika/js/tabs/assets/css/responsive-tabs3.css">

<!-- tooltips -->
<link rel="stylesheet" href="/knbc/templates/aaika/js/tooltips/darktooltip.css" />

<!-- owl carousel -->
<link href="/knbc/templates/aaika/js/carouselowl/owl.transitions.css" rel="stylesheet">
<link href="/knbc/templates/aaika/js/carouselowl/owl.carousel.css" rel="stylesheet">

<!-- timeline -->
<link rel="stylesheet" href="/knbc/templates/aaika/js/timeline/timeline.css">

<!-- image hover effects -->
<link rel="stylesheet" href="/knbc/templates/aaika/js/ihovereffects/main.css">

<!-- forms -->
<link rel="stylesheet" href="/knbc/templates/aaika/js/form/sky-forms2.css" type="text/css" media="all">
<link rel="stylesheet" href="/knbc/templates/aaika/js/form/sky-forms.css" type="text/css" media="all">

<link href="/knbc/templates/aaika/css/condition.css" rel="stylesheet" type="text/css" />
<link href="/knbc/templates/aaika/js/mainmenu/bootstrap.min.css" rel="stylesheet">
<link href="/knbc/templates/aaika/js/mainmenu/menu-3.css" rel="stylesheet">

<!-- tabs -->
<link rel="stylesheet" type="text/css" href="/knbc/templates/aaika/js/tabs/tabwidget/tabwidget.css" />

<!-- Color Css -->
<!-- Custom css -->
<link rel="stylesheet" href="/knbc/templates/aaika/css/custom.css" type="text/css" />
</head>
<!-- /head -->

<!-- =========================================
    body
    ========================================== -->
<body>
  <!-- Site_wraper-->
  <div class="site_wrapper">
        <!-- end slide wrap -->
    
    <header class="header ">
      <div class="container"> 
        
        <!-- Logo -->
        <div class="logo">
                    <a href="/knbc/index.php"><img src="/knbc/images/sliders/master/Logo II.png" alt="logo"></a>
                  </div>
        
        <!-- Navigation Menu -->
        <nav class="menu_main">
          <div class="navbar yamm navbar-default">
            <div class="container">
              <div class="navbar-header">
                <div class="navbar-toggle .navbar-collapse .pull-right " data-toggle="collapse" data-target="#navbar-collapse-1"  > <span>Menu</span>
                  <button type="button" > <i class="fa fa-bars"></i></button>
                </div>
              </div>
              <div id="navbar-collapse-1" class="navbar-collapse collapse pull-right">
                                <ul class="nav navbar-nav"><li class="dropdown iceMenuLiLevel_1 yamm-fw active"><a data-toggle="dropdown" href="http://localhost:8888/knbc/" class="active dropdown-toggle">
            Home
</a></li><li class="dropdown iceMenuLiLevel_1 "><a data-toggle="dropdown" href="/knbc/index.php/about-us" class=" dropdown-toggle">
            About
</a></li><li class="dropdown iceMenuLiLevel_1 "><a data-toggle="dropdown" href="/knbc/index.php/docks" class=" dropdown-toggle">
            Docks
</a></li><li class="dropdown iceMenuLiLevel_1 "><a data-toggle="dropdown" href="/knbc/index.php/gazebo-cabana" class=" dropdown-toggle">
            Gazebo &amp; Cabana
</a></li><li class="dropdown iceMenuLiLevel_1 "><a data-toggle="dropdown" href="/knbc/index.php/furniture-and-fire-pits" class=" dropdown-toggle">
            Furniture &amp; Fire Pits
</a></li><li class="dropdown iceMenuLiLevel_1 "><a data-toggle="dropdown" href="/knbc/index.php/construction" class=" dropdown-toggle">
            Construction
</a></li><li class="dropdown iceMenuLiLevel_1 "><a data-toggle="dropdown" href="#" class=" dropdown-toggle">
            Coming Soon
</a></li><li class="dropdown iceMenuLiLevel_1 "><a data-toggle="dropdown" href="/knbc/index.php/contact" class=" dropdown-toggle">
            Contact
</a></li></ul>


<script type="text/javascript">
	jQuery(document).ready(function(){
		var browser_width1 = jQuery(window).width();
		jQuery("#icemegamenu").find(".icesubMenu").each(function(index){
			var offset1 = jQuery(this).offset();
			var xwidth1 = offset1.left + jQuery(this).width();
			if(xwidth1 >= browser_width1){
				jQuery(this).addClass("ice_righttoleft");
			}
		});
		
	})
	jQuery(window).resize(function() {
		var browser_width = jQuery(window).width();
		jQuery("#icemegamenu").find(".icesubMenu").removeClass("ice_righttoleft");
		jQuery("#icemegamenu").find(".icesubMenu").each(function(index){
			var offset = jQuery(this).offset();
			var xwidth = offset.left + jQuery(this).width();
			
			if(xwidth >= browser_width){
				jQuery(this).addClass("ice_righttoleft");
			}
		});
	});
</script>
                              </div>
            </div>
          </div>
        </nav>
        <!-- end Navigation Menu -->
      </div>
    </header>
    <!-- Slider
======================================= -->
        <div class="rev_slider_wrapper">
      <!-- START REVOLUTION SLIDER 4.6 b1 fullwidth mode -->
<script type='text/javascript' src='http://localhost:8888/knbc/media/com_uniterevolution2/assets/rs-plugin/js/jquery.themepunch.tools.min.js'></script>
<script type='text/javascript' src='http://localhost:8888/knbc/media/com_uniterevolution2/assets/rs-plugin/js/jquery.themepunch.revolution.min.js'></script>

<div id="rev_slider_1_1_wrapper" class="rev_slider_wrapper fullwidthbanner-container" style="margin:0px auto;background-color:#E9E9E9;padding:0px;margin-top:0px;margin-bottom:0px;max-height:750px;">
	<div id="rev_slider_1_1" class="rev_slider fullwidthabanner" style="display:none;max-height:750px;height:750px;">
<ul>	<!-- SLIDE  1-->
	<li data-transition="random" data-slotamount="7" data-masterspeed="300"  data-saveperformance="off" >
		<!-- MAIN IMAGE -->
		<img src="http://localhost:8888/knbc/images/sliders/master/slider_3.jpg"  alt="slider_3"  data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat">
		<!-- LAYERS -->
	</li>
	<!-- SLIDE  2-->
	<li data-transition="random" data-slotamount="7" data-masterspeed="300"  data-saveperformance="off" >
		<!-- MAIN IMAGE -->
		<img src="http://localhost:8888/knbc/images/sliders/master/slider_1.jpg"  alt="slider_1"  data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat">
		<!-- LAYERS -->
	</li>
	<!-- SLIDE  3-->
	<li data-transition="random" data-slotamount="7" data-masterspeed="500"  data-saveperformance="off" >
		<!-- MAIN IMAGE -->
		<img src="http://localhost:8888/knbc/images/sliders/master/slider_2.jpg"  alt="slider_2"  data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat">
		<!-- LAYERS -->
	</li>
</ul>
<div class="tp-bannertimer tp-bottom" style="display:none; visibility: hidden !important;"></div>	</div>
			
			<script type="text/javascript">

					
				/******************************************
					-	PREPARE PLACEHOLDER FOR SLIDER	-
				******************************************/
								
				 
						var setREVStartSize = function() {
							var	tpopt = new Object(); 
								tpopt.startwidth = 1400;
								tpopt.startheight = 750;
								tpopt.container = jQuery('#rev_slider_1_1');
								tpopt.fullScreen = "off";
								tpopt.forceFullWidth="on";

							tpopt.container.closest(".rev_slider_wrapper").css({height:tpopt.container.height()});tpopt.width=parseInt(tpopt.container.width(),0);tpopt.height=parseInt(tpopt.container.height(),0);tpopt.bw=tpopt.width/tpopt.startwidth;tpopt.bh=tpopt.height/tpopt.startheight;if(tpopt.bh>tpopt.bw)tpopt.bh=tpopt.bw;if(tpopt.bh<tpopt.bw)tpopt.bw=tpopt.bh;if(tpopt.bw<tpopt.bh)tpopt.bh=tpopt.bw;if(tpopt.bh>1){tpopt.bw=1;tpopt.bh=1}if(tpopt.bw>1){tpopt.bw=1;tpopt.bh=1}tpopt.height=Math.round(tpopt.startheight*(tpopt.width/tpopt.startwidth));if(tpopt.height>tpopt.startheight&&tpopt.autoHeight!="on")tpopt.height=tpopt.startheight;if(tpopt.fullScreen=="on"){tpopt.height=tpopt.bw*tpopt.startheight;var cow=tpopt.container.parent().width();var coh=jQuery(window).height();if(tpopt.fullScreenOffsetContainer!=undefined){try{var offcontainers=tpopt.fullScreenOffsetContainer.split(",");jQuery.each(offcontainers,function(e,t){coh=coh-jQuery(t).outerHeight(true);if(coh<tpopt.minFullScreenHeight)coh=tpopt.minFullScreenHeight})}catch(e){}}tpopt.container.parent().height(coh);tpopt.container.height(coh);tpopt.container.closest(".rev_slider_wrapper").height(coh);tpopt.container.closest(".forcefullwidth_wrapper_tp_banner").find(".tp-fullwidth-forcer").height(coh);tpopt.container.css({height:"100%"});tpopt.height=coh;}else{tpopt.container.height(tpopt.height);tpopt.container.closest(".rev_slider_wrapper").height(tpopt.height);tpopt.container.closest(".forcefullwidth_wrapper_tp_banner").find(".tp-fullwidth-forcer").height(tpopt.height);}
						};
						
						/* CALL PLACEHOLDER */
						setREVStartSize();
								
				
				var tpj=jQuery;				
				tpj.noConflict();				
				var revapi1;
				
				
				
				tpj(document).ready(function() {
				
					
								
				if(tpj('#rev_slider_1_1').revolution == undefined)
					revslider_showDoubleJqueryError('#rev_slider_1_1');
				else
				   revapi1 = tpj('#rev_slider_1_1').show().revolution(
					{
						dottedOverlay:"none",
						delay:6000,
						startwidth:1400,
						startheight:750,
						hideThumbs:200,
						
						thumbWidth:100,
						thumbHeight:50,
						thumbAmount:3,
													
						simplifyAll:"off",						
						navigationType:"bullet",
						navigationArrows:"solo",
						navigationStyle:"round",						
						touchenabled:"on",
						onHoverStop:"off",						
						nextSlideOnWindowFocus:"off",
						
						swipe_threshold: 75,
						swipe_min_touches: 1,
						drag_block_vertical: false,
																		
																		
						keyboardNavigation:"off",
						
						navigationHAlign:"center",
						navigationVAlign:"bottom",
						navigationHOffset:0,
						navigationVOffset:20,

						soloArrowLeftHalign:"left",
						soloArrowLeftValign:"center",
						soloArrowLeftHOffset:20,
						soloArrowLeftVOffset:0,

						soloArrowRightHalign:"right",
						soloArrowRightValign:"center",
						soloArrowRightHOffset:20,
						soloArrowRightVOffset:0,
								
						shadow:0,
						fullWidth:"on",
						fullScreen:"off",

						spinner:"spinner0",
						
						stopLoop:"off",
						stopAfterLoops:-1,
						stopAtSlide:-1,

						shuffle:"off",
						
						autoHeight:"off",						
						forceFullWidth:"on",						
												
												
						hideTimerBar:"on",						
						hideThumbsOnMobile:"off",
						hideNavDelayOnMobile:1500,
						hideBulletsOnMobile:"off",
						hideArrowsOnMobile:"off",
						hideThumbsUnderResolution:0,
						
												hideSliderAtLimit:0,
						hideCaptionAtLimit:0,
						hideAllCaptionAtLilmit:0,
						startWithSlide:0,
						isJoomla: true
					});
					
					
					
									
				});	/*ready*/
									
			</script>
			
			</div>
<!-- END REVOLUTION SLIDER -->	
    </div>
        <!-- end slider -->
    
            <!-- end page title --> 
    
    <!-- content Section -->
        
    <!-- About Style 2 -->
                                                                        <div class="clearfix"></div>
    <div class="recent_works">
<div class="title2">
<h2><span class="line"></span><span class="text">Recent Works</span></h2>
</div>
<div class="margin_top2">&nbsp;</div>
<div class="clearfix">&nbsp;</div>
<div id="grid-container" class="cbp-l-grid-fullScreen animate" data-anim-type="fadeInUp" data-anim-delay="100">
<ul>
<li class="cbp-item"><a class="cbp-caption cbp-lightbox" data-title="Cabins">
<div class="cbp-caption-defaultWrap"><img src="/knbc/images/recentworks/SampleWork I.jpg" alt="" /></div>
<div class="cbp-caption-activeWrap">
<div class="cbp-l-caption-alignLeft">
<div class="cbp-l-caption-body">
<div class="cbp-l-caption-title">Cabins</div>
<!-- <div class="cbp-l-caption-desc">by joomlastars</div> --></div>
</div>
</div>
</a></li>
<li class="cbp-item"><a class="cbp-caption cbp-lightbox" data-title="Custom Projects">
<div class="cbp-caption-defaultWrap"><img src="/knbc/images/recentworks/SampleWork II.jpg" alt="" /></div>
<div class="cbp-caption-activeWrap">
<div class="cbp-l-caption-alignLeft">
<div class="cbp-l-caption-body">
<div class="cbp-l-caption-title">Custom Projects</div>
<!-- <div class="cbp-l-caption-desc">by joomlastars</div> --></div>
</div>
</div>
</a></li>
<li class="cbp-item"><a class="cbp-caption cbp-lightbox" data-title="Fire Pits">
<div class="cbp-caption-defaultWrap"><img src="/knbc/images/recentworks/SampleWork III.jpg" alt="" /></div>
<div class="cbp-caption-activeWrap">
<div class="cbp-l-caption-alignLeft">
<div class="cbp-l-caption-body">
<div class="cbp-l-caption-title">Fire Pits</div>
<!-- <div class="cbp-l-caption-desc">by joomlastars</div> --></div>
</div>
</div>
</a></li>
<li class="cbp-item"><a class="cbp-caption cbp-lightbox" data-title="Floating Docks">
<div class="cbp-caption-defaultWrap"><img src="/knbc/images/recentworks/SampleWork IV.jpg" alt="" /></div>
<div class="cbp-caption-activeWrap">
<div class="cbp-l-caption-alignLeft">
<div class="cbp-l-caption-body">
<div class="cbp-l-caption-title">Floating Docks</div>
<!-- <div class="cbp-l-caption-desc">by joomlastars</div> --></div>
</div>
</div>
</a></li>
<li class="cbp-item"><a class="cbp-caption cbp-lightbox" data-title="Handmade Furnitures">
<div class="cbp-caption-defaultWrap"><img src="/knbc/images/recentworks/SampleWork V.jpg" alt="" /></div>
<div class="cbp-caption-activeWrap">
<div class="cbp-l-caption-alignLeft">
<div class="cbp-l-caption-body">
<div class="cbp-l-caption-title">Handmade Furnitures</div>
<!-- <div class="cbp-l-caption-desc">by joomlastars</div> --></div>
</div>
</div>
</a></li>
<li class="cbp-item"><a class="cbp-caption cbp-lightbox" data-title="Lifts">
<div class="cbp-caption-defaultWrap"><img src="/knbc/images/recentworks/SampleWork VI.jpg" alt="" /></div>
<div class="cbp-caption-activeWrap">
<div class="cbp-l-caption-alignLeft">
<div class="cbp-l-caption-body">
<div class="cbp-l-caption-title">Lifts</div>
<!-- <div class="cbp-l-caption-desc">by joomlastars</div> --></div>
</div>
</div>
</a></li>
<li class="cbp-item"><a class="cbp-caption cbp-lightbox" data-title="Marine Railway">
<div class="cbp-caption-defaultWrap"><img src="/knbc/images/recentworks/SampleWork VII.jpg" alt="" /></div>
<div class="cbp-caption-activeWrap">
<div class="cbp-l-caption-alignLeft">
<div class="cbp-l-caption-body">
<div class="cbp-l-caption-title">Marine Railway</div>
<!-- <div class="cbp-l-caption-desc">by joomlastars</div> --></div>
</div>
</div>
</a></li>
<li class="cbp-item"><a class="cbp-caption cbp-lightbox" data-title="Pole Docks">
<div class="cbp-caption-defaultWrap"><img src="/knbc/images/recentworks/SampleWork VIII.jpg" alt="" /></div>
<div class="cbp-caption-activeWrap">
<div class="cbp-l-caption-alignLeft">
<div class="cbp-l-caption-body">
<div class="cbp-l-caption-title">Pole Docks</div>
<!-- <div class="cbp-l-caption-desc">by joomlastars</div> --></div>
</div>
</div>
</a></li>
</ul>
</div>
</div>
        <!-- end recent works -->
        <!-- end features section 2 -->
    
                                                                                                                    <div class="clearfix"></div>
    <div class="features_sec14">
      <div class="container">
        <div class="one_fourth animate" data-anim-type="fadeIn" data-anim-delay="100"><img src="/knbc/templates/aaika/images/clogo1.png" alt="" /></div>
<div class="one_fourth animate" data-anim-type="fadeIn" data-anim-delay="150"><img src="/knbc/templates/aaika/images/clogo2.png" alt="" /></div>
<div class="one_fourth animate" data-anim-type="fadeIn" data-anim-delay="200"><img src="/knbc/templates/aaika/images/clogo3.png" alt="" /></div>
<div class="one_fourth last animate" data-anim-type="fadeIn" data-anim-delay="300"><img src="/knbc/templates/aaika/images/clogo4.png" alt="" /></div>
      </div>
    </div>
    <!-- end features section 14 -->
            <div class="clearfix"></div>
    <footer class="footer">
                  <div class="clearfix"></div>
      <div class="container">
        <div class="one_fourth animate" data-anim-type="fadeInUp" data-anim-delay="300">
    <ul class="faddress">
<li><img src="/knbc/templates/aaika/images/footer-logo.png" alt="" /></li>
<li><i class="fa fa-map-marker fa-lg"></i>&nbsp; 741 Moira Road, Stirling,<br /> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ontario, K0K 3E0</li>
<li><i class="fa fa-phone"></i>&nbsp; 1 -613 -827 -5597</li>
<li><a href="mailto:knbcsupplycorp@gmail.com"><i class="fa fa-envelope"></i>&nbsp; knbcsupplycorp@gmail.com</a></li>
</ul> </div>
<div class="one_fourth animate" data-anim-type="fadeInUp" data-anim-delay="300">
    <h4 class="lmb">Useful Links</h4>
    
<div class="qlinks">
  <ul>
    <li class="item-345"><a href="http://www.limestonebb.com/" onclick="window.open(this.href,'targetWindow','toolbar=no,location=no,status=no,menubar=no,scrollbars=yes,resizable=yes,');return false;" ><i class="fa fa-angle-right" ></i> Limestone BNB</a>
</li><li class="item-346"><a href="#" onclick="window.open(this.href,'targetWindow','toolbar=no,location=no,status=no,menubar=no,scrollbars=yes,resizable=yes,');return false;" ><i class="fa fa-angle-right" ></i> KNBC Haulage &amp; Removal</a>
</li><li class="item-347"><a href="https://onthewaterdesigns.com" onclick="window.open(this.href,'targetWindow','toolbar=no,location=no,status=no,menubar=no,scrollbars=yes,resizable=yes,');return false;" ><i class="fa fa-angle-right" ></i> On The Water Designs</a>
</li>  </ul>
</div>
 </div>
<div class="one_fourth siteinfo animate" data-anim-type="fadeInUp" data-anim-delay="300">
    <h4 class="lmb">About Us</h4>
    <p>KNBC Island Supply is a locally owned and operated corporation in Central Frontenac and Prince Edward County, Ontario.</p>
<p>&nbsp;</p>
<p>We distribute high quality, Canadian made and hand-crafted products that are very versatile and long lasting. We are passionate about supporting local small businesses and adding to the life and success of our community.</p> </div>

      </div>
      <!-- end footer -->
                  <div class="clearfix"></div>
      <div class="copyright_info">
        <div class="container">
          <div class="clearfix divider_dashed10"></div>
          <div class="one_half animate" data-anim-type="fadeInRight" data-anim-delay="300">
            <p>Copyright © 2022 KNBC Island Supply Corporation. All rights reserved.</p>
          </div>
          <div class="one_half last">
            <ul class="footer_social_links">
              
            </ul>
          </div>
        </div>
      </div>
      <!-- end copyright info -->
          </footer>
    <a href="#" class="scrollup">Scroll</a><!-- end scroll to top of the page--> 
  </div>
  <!-- End Site_wraper-->
  <!-- ######### JS FILES ######### --> 
<!-- get jQuery from the google apis --> 
<script type="text/javascript" src="/knbc/templates/aaika/js/universal/jquery.js"></script> 

<!-- style switcher --> 
<script src="/knbc/templates/aaika/js/style-switcher/jquery.js"></script> 

<!-- animations --> 
<script src="/knbc/templates/aaika/js/animations/js/animations.min.js" type="text/javascript"></script> 

<!-- slide panel --> 
<script type="text/javascript" src="/knbc/templates/aaika/js/slidepanel/slidepanel.js"></script> 

<!-- mega menu --> 
<script src="/knbc/templates/aaika/js/mainmenu/bootstrap.min.js"></script> 
<script src="/knbc/templates/aaika/js/mainmenu/customeUI.js"></script> 

<script type="text/javascript">
jQuery(document).ready(function() {
	jQuery( ".iceMenuLiLevel_1" ).each(function() {
	  if(jQuery( this ).find(".dropdown-menu").length==0){
			jQuery(this).find(".dropdown-toggle").removeAttr("data-toggle")
		}
	});
});
</script>

<!-- tab widget --> 
<script type="text/javascript" src="/knbc/templates/aaika/js/tabs/tabwidget/tabwidget.js"></script> 

<!-- scroll up --> 
<script src="/knbc/templates/aaika/js/scrolltotop/totop.js" type="text/javascript"></script> 

<!-- sticky menu --> 
<script type="text/javascript" src="/knbc/templates/aaika/js/mainmenu/sticky-main.js"></script> 
<script type="text/javascript" src="/knbc/templates/aaika/js/mainmenu/modernizr.custom.75180.js"></script> 

<!-- cubeportfolio --> 
<script type="text/javascript" src="/knbc/templates/aaika/js/cubeportfolio/jquery.cubeportfolio.min.js"></script> 
<script type="text/javascript" src="/knbc/templates/aaika/js/cubeportfolio/main.js"></script> 
<script type="text/javascript" src="/knbc/templates/aaika/js/cubeportfolio/main2.js"></script> 
<script type="text/javascript" src="/knbc/templates/aaika/js/cubeportfolio/main3.js"></script> 
<script type="text/javascript" src="/knbc/templates/aaika/js/cubeportfolio/main4.js"></script> 
<script type="text/javascript" src="/knbc/templates/aaika/js/cubeportfolio/main5.js"></script> 
<script type="text/javascript" src="/knbc/templates/aaika/js/cubeportfolio/main6.js"></script> 
<script type="text/javascript" src="/knbc/templates/aaika/js/cubeportfolio/main7.js"></script> 
<!-- Accordion--> 
<script type="text/javascript" src="/knbc/templates/aaika/js/accordion/jquery.accordion.js"></script> 
<script type="text/javascript" src="/knbc/templates/aaika/js/accordion/custom.js"></script> 

<!-- progress bar --> 
<script src="/knbc/templates/aaika/js/progressbar/progress.js" type="text/javascript" charset="utf-8"></script> 

<!-- flexslider --> 
<script defer src="/knbc/templates/aaika/js/flexslider/jquery.flexslider.js"></script> 
<script defer src="/knbc/templates/aaika/js/flexslider/custom.js"></script> 

<!-- basic slider --> 
<script type="text/javascript" src="/knbc/templates/aaika/js/basicslider/bacslider.js"></script> 
<script type="text/javascript">
(function($) {
 "use strict";
 
	$(document).ready(function() {
		$(".main-slider-container").sliderbac();
	});
	
})(jQuery);
</script> 

<!-- tabs --> 
<script src="/knbc/templates/aaika/js/tabs/assets/js/responsive-tabs.min.js" type="text/javascript"></script> 

<!-- tooltips --> 
<script src="/knbc/templates/aaika/js/tooltips/jquery.darktooltip.js"></script> 

<!-- owl carousel --> 
<script src="/knbc/templates/aaika/js/carouselowl/owl.carousel.js"></script> 
<script src="/knbc/templates/aaika/js/carouselowl/custom.js"></script> 

<!-- animate number --> 
<script src="/knbc/templates/aaika/js/aninum/jquery.animateNumber.min.js"></script> 
<script src="/knbc/templates/aaika/js/timeline/modernizr.js"></script> 
<script type="text/javascript" src="/knbc/templates/aaika/js/universal/custom.js"></script> 

<!-- MasterSlider --> 
<script src="/knbc/templates/aaika/js/masterslider/jquery.easing.min.js"></script> 
<script src="/knbc/templates/aaika/js/masterslider/masterslider.min.js"></script> 
<script type="text/javascript">
(function($) {
 "use strict";
	var slider2 = new MasterSlider();

	 slider2.setup('masterslider2' , {
		 width:1400,    // slider standard width
		 height:520,   // slider standard height
		 space:0,
		 speed:45,
		 layout:'fullwidth',
		 loop:true,
		 preload:0,
		 autoplay:true,
		 view:"basic"
	});
	
})(jQuery);
</script> 
<script type="text/javascript">      
 (function(jQuery) {
 "use strict";
 
    var slider = new MasterSlider();
 
    slider.control('arrows');  
    slider.control('lightbox');
    slider.control('thumblist' , {autohide:false ,dir:'h',align:'bottom', width:130, height:85, margin:5, space:5 , hideUnder:400});
 
    slider.setup('masterslider' , {
        width:750,
        height:400,
        space:5,
        loop:true,
        view:'fade'
    });
     
    jQuery(document).ready(function(){
        jQuery("a[rel^='prettyPhoto']").prettyPhoto();
    });

})(jQuery);
</script> 
<script type="text/javascript">
(function($) {
 "use strict";

	var slider = new MasterSlider();
	// adds Arrows navigation control to the slider.

	 slider.setup('slideshow4' , {
		 width:1400,    // slider standard width
		 height:750,   // slider standard height
		 space:0,
		 speed:45,
		 layout:'fullwidth',
		 loop:true,
		 preload:0,
		 autoplay:true,
		 view:"basic"
	});
	
})(jQuery);
</script> 
<script src="/knbc/templates/aaika/js/masterslider/jquery.prettyPhoto.js"></script> 

<!-- classyloader--> 
<script src="/knbc/templates/aaika/js/classyloader/jquery.classyloader.min.js"></script> 
<script src="/knbc/templates/aaika/js/custom.js"></script>
</body>
<!-- /body -->
</html>
<!-- /html -->